need to consider adding a baby/naive MNIST example here
(will give this a bit more meat) and also smooth the transition to
next weeks code
